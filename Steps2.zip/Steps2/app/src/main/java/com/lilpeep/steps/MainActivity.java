package com.lilpeep.steps;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.lilpeep.steps.databinding.ActivityMainBinding;

import java.io.Serializable;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements SensorEventListener, Serializable {

    private final int MY_PERMISSIONS_REQUEST_ACTIVITY_RECOGNITION = 100;
    private ActivityMainBinding binding;
    private TextView textViewSteps;
    private TextView textViewKm;
    private TextView textViewKkal;

    SensorManager sensorManager;
    AlarmManager alarmMgr;
    PendingIntent pendingIntent;

    long time = 0;
    int totalSteps = 0;
    int offTotalSteps = 0;
    float hProgress = 0;
    float wProgress = 0;
    float offSteps = 0;
    long Steps = 0;
    float previousSteps = 0;
    float km = 0;
    float kal = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications).build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, MY_PERMISSIONS_REQUEST_ACTIVITY_RECOGNITION);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        textViewSteps = findViewById(R.id.Steps);
        textViewKkal = findViewById(R.id.Kkal);
        textViewKm = findViewById(R.id.Km);

        cancelAlarm();
        startAlarm();
        loadData();
    }

    @Override
    public void onResume() {
        super.onResume();

        Sensor countsensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (countsensor != null) {
            sensorManager.registerListener(this, countsensor, SensorManager.SENSOR_DELAY_UI);
        } else {
            textViewSteps.setText("Ваше устройство устаревшее");
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {textViewSteps.setText("Требуются права");}
        else {
            loadData();
            Steps = (long) event.values[0];

            SharedPreferences prefs = getPreferences(MODE_PRIVATE);
            if (prefs.getBoolean("isFirstRun",true)) {
                offSteps = 0; saveDataOffSteps(); previousSteps = offSteps + Steps; saveDataPreviousSteps();
                cancelAlarm();
                startAlarm();
                prefs.edit().putBoolean("isFirstRun", false).apply();
            }
            else {if (Steps == 0){ previousSteps = 0; saveDataPreviousSteps(); loadDataTotalSteps(); offSteps = offTotalSteps; saveDataOffSteps(); }}

            totalSteps = (int) (offSteps + Steps - previousSteps);
            saveDataTotalSteps(); saveDataSteps();
            textViewSteps.setText(String.valueOf(totalSteps));
            loadDataSettings();
            km = (float) ((totalSteps * ((hProgress / 465) + 0.37)) / 1000); kal = (float) (0.5 * wProgress * km);
            textViewKm.setText(String.format("%.2f",km));  textViewKkal.setText(String.format("%.2f",kal));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private void startAlarm(){
        Calendar rightNow = Calendar.getInstance();
        long offset = rightNow.get(Calendar.ZONE_OFFSET)+rightNow.get(Calendar.DST_OFFSET);
        long sinceMidnight = (rightNow.getTimeInMillis()+offset)%(24*60*60*1000);
        time = 86400000-sinceMidnight;

        Intent intent = new Intent(getBaseContext(), MyAlarmReceiver.class);
        alarmMgr = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
        alarmMgr.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime()+time,pendingIntent);
    }

    private void cancelAlarm(){
        Intent intent = new Intent(getBaseContext(), MyAlarmReceiver.class);
        alarmMgr = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);
        alarmMgr.cancel(pendingIntent);
    }

    private void saveDataSteps() {
        SharedPreferences sharedPreferencesSteps = getSharedPreferences("Steps", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorSteps = sharedPreferencesSteps.edit();
        editorSteps.putLong("Steps", Steps);
        editorSteps.apply();
    }

    private void saveDataPreviousSteps() {
        SharedPreferences sharedPreferencesPrSteps = getSharedPreferences("PreviousSteps", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorPrSteps = sharedPreferencesPrSteps.edit();
        editorPrSteps.putFloat("prSteps",previousSteps);
        editorPrSteps.apply();
    }

    private void loadData() {
        SharedPreferences sharedPreferencesPrSteps = getSharedPreferences("PreviousSteps", Context.MODE_PRIVATE);
        float savedPrSteps = sharedPreferencesPrSteps.getFloat("prSteps",0);
        Log.d("PrSteps", String.valueOf(savedPrSteps));
        previousSteps = savedPrSteps;
        SharedPreferences sharedPreferencesOffSteps = getSharedPreferences("OffSteps", Context.MODE_PRIVATE);
        int savedOffSteps = sharedPreferencesOffSteps.getInt("ofSteps",0);
        Log.d("offSteps", String.valueOf(savedOffSteps));
        offSteps=savedOffSteps;
    }

    private void saveDataTotalSteps() {
        SharedPreferences sharedPreferencesTotalSteps = getSharedPreferences("TotalSteps", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorTotalSteps = sharedPreferencesTotalSteps.edit();
        editorTotalSteps.putInt("TlSteps",totalSteps);
        editorTotalSteps.apply();
    }

    private void loadDataTotalSteps() {
        SharedPreferences sharedPreferencesTotalSteps = getSharedPreferences("TotalSteps", Context.MODE_PRIVATE);
        int savedTotalSteps = sharedPreferencesTotalSteps.getInt("TlSteps",0);
        Log.d("totalSteps", String.valueOf(savedTotalSteps));
        offTotalSteps = savedTotalSteps;
    }

    private void saveDataOffSteps() {
        SharedPreferences sharedPreferencesOffSteps = getSharedPreferences("OffSteps", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorOffSteps = sharedPreferencesOffSteps.edit();
        editorOffSteps.putInt("ofSteps", (int) offSteps);
        editorOffSteps.apply();
    }

    private void loadDataSettings() {
        SharedPreferences sharedPreferencesHeight = getSharedPreferences("HeightProgress", Context.MODE_PRIVATE);
        int savedHeight = sharedPreferencesHeight.getInt("hProgress",180);
        Log.d("Height", String.valueOf(savedHeight));
        hProgress = savedHeight;
        SharedPreferences sharedPreferencesWeight = getSharedPreferences("WeightProgress", Context.MODE_PRIVATE);
        int savedWeight = sharedPreferencesWeight.getInt("wProgress",50);
        Log.d("Weight", String.valueOf(savedWeight));
        wProgress = savedWeight;
    }
}