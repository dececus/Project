package com.lilpeep.steps;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.util.Log;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class MyAlarmReceiver extends BroadcastReceiver implements Serializable   {

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("/MM"); LocalDateTime dt = LocalDateTime.now(); String month = dt.format(formatter);
    DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("/yy"); LocalDateTime dt2 = LocalDateTime.now(); String year = dt2.format(formatter2);
    DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("dd"); LocalDateTime dt3 = LocalDateTime.now(); int day = Integer.parseInt(dt3.format(formatter3));
    String date = (day - 1) + month + year;
    AlarmManager alarmMgr;
    PendingIntent pendingIntent;
    long time = 0;
    float offSteps = 0;
    float hProgress = 0;
    float wProgress = 0;
    long Steps = 0;
    float previousSteps = 0;
    float km = 0;
    float kal = 0;
    String ras = "";
    String flame = "";
    String step = "";
    String dat = "";
    String ResultKm = "";
    String ResultKal = "";

    @Override
    public void onReceive(Context context, Intent intent) {

        Intent intenttt = new Intent(context, MyAlarmReceiver.class);
        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(context, 0, intenttt, 0);
        alarmMgr.cancel(pendingIntent);

        Calendar rightNow = Calendar.getInstance();
        long offset = rightNow.get(Calendar.ZONE_OFFSET)+rightNow.get(Calendar.DST_OFFSET);
        long sinceMidnight = (rightNow.getTimeInMillis()+offset)%(24*60*60*1000);
        time = 86400000-sinceMidnight;

        Intent intentt = new Intent(context, MyAlarmReceiver.class);
        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(context, 0, intentt, 0);
        alarmMgr.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime()+time,pendingIntent);


        SharedPreferences sharedPreferencesOffSteps = context.getSharedPreferences("OffSteps", Context.MODE_PRIVATE);
        int savedOffSteps = sharedPreferencesOffSteps.getInt("ofSteps",0);
        Log.d("offSteps", String.valueOf(savedOffSteps));
        offSteps=savedOffSteps;
        SharedPreferences sharedPreferencesPrSteps = context.getSharedPreferences("PreviousSteps", Context.MODE_PRIVATE);
        float savedPrSteps = sharedPreferencesPrSteps.getFloat("prSteps",0);
        Log.d("PrSteps", String.valueOf(savedPrSteps));
        previousSteps = savedPrSteps;
        SharedPreferences sharedPreferencesDatL = context.getSharedPreferences("Dat", Context.MODE_PRIVATE);
        String savedDat = sharedPreferencesDatL.getString("Dat", "");
        Log.d("Dat", savedDat);
        dat = savedDat;
        SharedPreferences sharedPreferencesRasL = context.getSharedPreferences("Ras", Context.MODE_PRIVATE);
        String savedRas = sharedPreferencesRasL.getString("Ras", "");
        Log.d("Ras", savedRas);
        ras = savedRas;
        SharedPreferences sharedPreferencesFlameL = context.getSharedPreferences("Flame", Context.MODE_PRIVATE);
        String savedFlame = sharedPreferencesFlameL.getString("Flame", "");
        Log.d("Flame", savedFlame);
        flame = savedFlame;
        SharedPreferences sharedPreferencesStepL = context.getSharedPreferences("Step", Context.MODE_PRIVATE);
        String savedStep = sharedPreferencesStepL.getString("Step", "");
        Log.d("Step", savedStep);
        step = savedStep;
        SharedPreferences sharedPreferencesHeight = context.getSharedPreferences("HeightProgress", Context.MODE_PRIVATE);
        int savedHeight = sharedPreferencesHeight.getInt("hProgress",180);
        Log.d("Height", String.valueOf(savedHeight));
        hProgress = savedHeight;
        SharedPreferences sharedPreferencesWeight = context.getSharedPreferences("WeightProgress", Context.MODE_PRIVATE);
        int savedWeight = sharedPreferencesWeight.getInt("wProgress",50);
        Log.d("Weight", String.valueOf(savedWeight));
        wProgress = savedWeight;
        SharedPreferences sharedPreferencesSteps = context.getSharedPreferences("Steps", Context.MODE_PRIVATE);
        long savedSteps = sharedPreferencesSteps.getLong("Steps",0);
        Log.d("Steps", String.valueOf(savedSteps));
        Steps = savedSteps;


        km = (float) ((((int) (offSteps + Steps - previousSteps)) * ((hProgress / 465) + 0.37)) / 1000); kal = (float) (0.5 * wProgress * km); ResultKm = String.format("%.2f",km);  ResultKal = String.format("%.2f",kal);
        dat = dat + date + "\n";
        ras = ras + ResultKm + "\n";
        flame = flame + ResultKal + "\n";
        step = step + ((int) (offSteps + Steps - previousSteps)) + "\n";
        offSteps = 0; previousSteps = offSteps + Steps;
        Steps = 0;

        //Пробный код ------------------------------------------------------------------------------------------------------------
        SharedPreferences settingsSteps = context.getSharedPreferences("Steps", Context.MODE_PRIVATE);
        settingsSteps.edit().clear().apply();
        SharedPreferences settingsPreviousSteps = context.getSharedPreferences("PreviousSteps", Context.MODE_PRIVATE);
        settingsPreviousSteps.edit().clear().apply();
        SharedPreferences settingsDat = context.getSharedPreferences("Dat", Context.MODE_PRIVATE);
        settingsDat.edit().clear().apply();
        SharedPreferences settingsRas = context.getSharedPreferences("Ras", Context.MODE_PRIVATE);
        settingsRas.edit().clear().apply();
        SharedPreferences settingsFlame = context.getSharedPreferences("Flame", Context.MODE_PRIVATE);
        settingsFlame.edit().clear().apply();
        SharedPreferences settingsStep = context.getSharedPreferences("Step", Context.MODE_PRIVATE);
        settingsStep.edit().clear().apply();
        SharedPreferences settingsOffSteps = context.getSharedPreferences("OffSteps", Context.MODE_PRIVATE);
        settingsOffSteps.edit().clear().apply();
        SharedPreferences settingsTotalSteps = context.getSharedPreferences("TotalSteps", Context.MODE_PRIVATE);
        settingsTotalSteps.edit().clear().apply();
        //Пробный код ------------------------------------------------------------------------------------------------------------

        SharedPreferences sharedPreferencesStepsL = context.getSharedPreferences("Steps", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorStepsL = sharedPreferencesStepsL.edit();
        editorStepsL.putLong("Steps",Steps);
        editorStepsL.apply();
        SharedPreferences sharedPreferencesPrStepsS = context.getSharedPreferences("PreviousSteps", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorPrStepsS = sharedPreferencesPrStepsS.edit();
        editorPrStepsS.putFloat("prSteps",previousSteps);
        editorPrStepsS.apply();
        SharedPreferences sharedPreferencesDat = context.getSharedPreferences("Dat", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorDat = sharedPreferencesDat.edit();
        editorDat.putString("Dat",dat);
        editorDat.apply();
        SharedPreferences sharedPreferencesRas = context.getSharedPreferences("Ras", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorRas = sharedPreferencesRas.edit();
        editorRas.putString("Ras",ras);
        editorRas.apply();
        SharedPreferences sharedPreferencesFlame = context.getSharedPreferences("Flame", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorFlame = sharedPreferencesFlame.edit();
        editorFlame.putString("Flame",flame);
        editorFlame.apply();
        SharedPreferences sharedPreferencesStep = context.getSharedPreferences("Step", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorStep = sharedPreferencesStep.edit();
        editorStep.putString("Step",step);
        editorStep.apply();
        SharedPreferences sharedPreferencesOffStepsS = context.getSharedPreferences("OffSteps", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorOffStepsS = sharedPreferencesOffStepsS.edit();
        editorOffStepsS.putInt("ofSteps", (int) offSteps);
        editorOffStepsS.apply();
    }
}
