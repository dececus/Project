package com.lilpeep.steps.ui.settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.lilpeep.steps.R;
import com.lilpeep.steps.databinding.FragmentSettingsBinding;

public class settingsFragment extends Fragment {

    int hProgress = 0;
    int wProgress = 0;

    private FragmentSettingsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSettingsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onStart() {
        super.onStart();

        SeekBar Height = getActivity().findViewById(R.id.SBheight);
        SeekBar Weight = getActivity().findViewById(R.id.SBweight);
        TextView tvHeight = getActivity().findViewById(R.id.heightR);
        TextView tvWeight = getActivity().findViewById(R.id.weightR);

        loadData();

        Height.setProgress(hProgress); tvHeight.setText(String.valueOf(hProgress)); Weight.setProgress(wProgress); tvWeight.setText(String.valueOf(wProgress));

        Height.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                hProgress = seekBar.getProgress();
                saveDataHeight();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvHeight.setText(String.valueOf(seekBar.getProgress()));
            }
        });

        Weight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                wProgress = seekBar.getProgress();
                saveDataWeight();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvWeight.setText(String.valueOf(seekBar.getProgress()));
            }
        });
    }

    private void saveDataHeight() {
        SharedPreferences sharedPreferencesHeight = getActivity().getSharedPreferences("HeightProgress", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorHeight = sharedPreferencesHeight.edit();
        editorHeight.putInt("hProgress", hProgress);
        editorHeight.apply();
    }

    private void saveDataWeight() {
        SharedPreferences sharedPreferencesWeight = getActivity().getSharedPreferences("WeightProgress", Context.MODE_PRIVATE);
        SharedPreferences.Editor editorWeight = sharedPreferencesWeight.edit();
        editorWeight.putInt("wProgress", wProgress);
        editorWeight.apply();
    }

    private void loadData() {
        SharedPreferences sharedPreferencesHeight = getActivity().getSharedPreferences("HeightProgress", Context.MODE_PRIVATE);
        int savedHeight = sharedPreferencesHeight.getInt("hProgress",180);
        Log.d("Height", String.valueOf(savedHeight));
        hProgress = savedHeight;
        SharedPreferences sharedPreferencesWeight = getActivity().getSharedPreferences("WeightProgress", Context.MODE_PRIVATE);
        int savedWeight = sharedPreferencesWeight.getInt("wProgress",50);
        Log.d("Weight", String.valueOf(savedWeight));
        wProgress = savedWeight;
    }
}