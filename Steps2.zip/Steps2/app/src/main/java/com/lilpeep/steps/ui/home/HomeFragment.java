package com.lilpeep.steps.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.lilpeep.steps.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private static View currFragment = null;

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        if(currFragment == null){
            binding = FragmentHomeBinding.inflate(inflater, container, false);
            View root = binding.getRoot();
            currFragment = root;
            return root;
        } else {
            return currFragment;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}