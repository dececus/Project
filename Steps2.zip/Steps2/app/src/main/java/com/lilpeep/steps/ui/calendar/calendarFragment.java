package com.lilpeep.steps.ui.calendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.lilpeep.steps.R;
import com.lilpeep.steps.databinding.FragmentCalendarBinding;

public class calendarFragment extends Fragment {

    private String str = "";
    private FragmentCalendarBinding binding;
    String ras = "";
    String flame = "";
    String step = "";
    String dat = "";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentCalendarBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onStart() {
        super.onStart();

        loadDataStr();
        TextView tv = getActivity().findViewById(R.id.text_calendar);
        TextView tv2 = getActivity().findViewById(R.id.text_calendar2);
        TextView tv3 = getActivity().findViewById(R.id.text_calendar3);
        TextView tv4 = getActivity().findViewById(R.id.text_calendar4);

        tv.setText(dat);
        tv2.setText(step);
        tv3.setText(ras);
        tv4.setText(flame);
    }

    private void loadDataStr() {
        SharedPreferences sharedPreferencesDatL = getActivity().getSharedPreferences("Dat", Context.MODE_PRIVATE);
        String savedDat = sharedPreferencesDatL.getString("Dat", "");
        Log.d("Dat", savedDat);
        dat = savedDat;
        SharedPreferences sharedPreferencesRasL = getActivity().getSharedPreferences("Ras", Context.MODE_PRIVATE);
        String savedRas = sharedPreferencesRasL.getString("Ras", "");
        Log.d("Ras", savedRas);
        ras = savedRas;
        SharedPreferences sharedPreferencesFlameL = getActivity().getSharedPreferences("Flame", Context.MODE_PRIVATE);
        String savedFlame = sharedPreferencesFlameL.getString("Flame", "");
        Log.d("Flame", savedFlame);
        flame = savedFlame;
        SharedPreferences sharedPreferencesStepL = getActivity().getSharedPreferences("Step", Context.MODE_PRIVATE);
        String savedStep = sharedPreferencesStepL.getString("Step", "");
        Log.d("Step", savedStep);
        step = savedStep;
    }
}